import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/game_one_screen.dart';
import 'screens/game_two_screen.dart';
import 'screens/game_three_screen.dart';
import 'screens/promociones_screen.dart';
import 'screens/select_character_screen.dart';
import 'screens/select_game_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const HappyJumpingApp());
}

class HappyJumpingApp extends StatelessWidget {
  const HappyJumpingApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Happy & Jumping',
      theme: ThemeData(
        fontFamily: 'Jaro',
      ),
      initialRoute: '/',
      routes: {
        '/':                 (context) => const LoginScreen(),
        '/home':             (context) => const HomeScreen(),
        '/select_character': (context) => const SelectCharacterScreen(),
        '/select_game':      (context) => const SelectGameScreen(),
        '/game1':            (context) => const GameOneScreen(),
        '/game2':            (context) => const GameTwoScreen(),
        '/game3':            (context) => const GameThreeScreen(),
        '/promociones':      (context) => const PromocionesScreen(),
        //'/historial':        (context) => const HistorialScreen(),
      },
    );
  }
}